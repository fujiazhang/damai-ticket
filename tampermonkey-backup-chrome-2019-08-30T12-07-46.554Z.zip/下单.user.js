// ==UserScript==
// @name         下单
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://buy.damai.cn/orderConfirm*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    //默认第一个用户
    document.getElementsByTagName('label')[4].click()
    document.getElementsByTagName('button')[2].click()
    // Your code here...
})();