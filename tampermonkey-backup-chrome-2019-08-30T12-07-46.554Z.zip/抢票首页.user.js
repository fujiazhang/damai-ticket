// ==UserScript==
// @name         抢票首页
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        *.damai.cn/item*
// @grant        none
// ==/UserScript==
(function() {
    'use strict';
    // Your code here...
   function clickBtn(){
    let btn = document.getElementsByClassName('buybtn')[0]
    let item =  document.getElementsByClassName('select_right_list_item ')[7]
    if(btn.innerHTML != '即将开售'){
        btn.click()
    }else{
        //location.reload()
    }
}

let timer = setInterval(() => {
    console.log('未加载到btn')
    if(document.getElementsByClassName('buybtn')[0]){
        console.log('已加载出btn,开始判断点击')
        clickBtn()
        window.clearInterval(timer)
    }
},0);
})();